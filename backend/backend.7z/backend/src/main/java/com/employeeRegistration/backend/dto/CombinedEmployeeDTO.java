package com.employeeRegistration.backend.dto;

import lombok.Data;

@Data
public class CombinedEmployeeDTO {
    private Long id;
    private String firstName;
    private String lastName;
    private String address;
    private String phoneNumber;


}

